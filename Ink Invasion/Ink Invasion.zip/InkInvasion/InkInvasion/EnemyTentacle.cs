﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InkInvasion
{
    class EnemyTentacle : Enemy
    {

        private float Wave;                 // The wave path that tentacles move on
        private bool waveIncrease;          // True if the tentacle is going up the wave, false if the tentacle is going down the wave

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="waveNumber">The current wave number</param>
        /// <param name="windowWidth">The width of the window</param>
        /// <param name="windowHeight">The height of the window</param>
        /// <param name="theIndex">The index of the enemy in the List of enemies (in the Game1 class)</param>
        public EnemyTentacle(int waveNumber, int windowWidth, int windowHeight, int theIndex)
            : base(waveNumber, windowWidth, windowHeight, theIndex)
        {
            index = theIndex;            
            type = "T";                                         // This enemy is a tentacle
            waveCounter = waveNumber;

            Wave = 0;

            waveIncrease = true;

            EnemySpawnLocation(windowWidth, windowHeight);

            health = 10 + (10 * (waveNumber / 6));              // Increase the tentacle's health by 10 every 6 waves

            //Change the tentacles's speed starting 5 waves after tentacles first appear
            if (waveNumber > 8)
                    moveSpeed = rnd.Next(2, 5);                 // Speed between 2 and 4
            else
                moveSpeed = 2;                                  // Default speed of 2

            damage = 1;                                         // Tentacle deals 1 damage

            enemyBoundBox = new Rectangle((int)XLoc, (int)YLoc, WIDTH, HEIGHT);

            attackTimer = 0;                                    // They start with not delay on attack
        }

        /// <summary>
        /// Override the abstract Move from enemy
        /// </summary>
        /// <param name="PlayerX">The player's x-value</param>
        /// <param name="PlayerY">The player's y-value</param>
        public override void Move(float PlayerX, float PlayerY)
        {
            // The distances from the player
            xDis = XLoc - PlayerX;
            yDis = YLoc - PlayerY;

            rotationAngle = (float)Math.Atan2(yDis, xDis);                                                      // Find the angle to fluctuate on

            XLoc -= (float)(moveSpeed * Math.Cos(rotationAngle)) + (float)(Math.Sin(rotationAngle) * Wave);     // Fluctuate the x value of the enemy a lot...
            YLoc -= (float)(moveSpeed * Math.Sin(rotationAngle)) + (float)(Math.Cos(rotationAngle) * Wave);     // Fluctuate the y value of the enemy a lot...

            // Fluctuate the y value of the enemy
            enemyBoundBox.X = (int)XLoc;
            enemyBoundBox.Y = (int)YLoc;

            // Modifying the wave value and thus the tentacle's dispositions
            // The max value of the wave is 4 and the min value of the wave is -4
            if (waveIncrease)
            {
                Wave += (float)(double).2;
                if (Wave > 4)
                {
                    waveIncrease = false;
                }
            }
            else
            {
                Wave -= (float)(double).2;
                if (Wave < -4)
                {
                    waveIncrease = true;
                }
            }
        }

        /// <summary>
        /// Deteremins how much ink a tentacle drops
        /// </summary>
        /// <returns>The amount the tentacle drops</returns>
        public override int Drop()
        {
            return 2 + (waveCounter / 5);       // Base drop of 2, Increase the amount the tentacle drops every 5 waves
        }
    }
}
