using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace InkInvasion
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        #region attributes

        GraphicsDeviceManager graphics;         // The graphics device manager 
        SpriteBatch spriteBatch;                // The spritebatch
        SpriteFont font;                        // The spritefont for drawing the HUD

        SoundEffect menuMusic, gameMusic;       //The music.
        bool playGameMusic, playMenuMusic;      //Controls the music.
        SoundEffectInstance menuMusicInstance;
        SoundEffectInstance gameMusicInstance; //Allows loops.


        Player p;                               // Create a player

        // Texture2Ds for bullets, the player, octopuses, slugs, tentacles, the menu title, the background, the player dying, and the enemy dying, the health upgrade icon, the ink bottle, the health bar pen
        // the damage upgrade icon, the word HEALTH, the word WAVE, the words GAME OVER, the play button, the instructions button, the quit button
        Texture2D bulletSkin, playerSkin, octopusSkin, slugSkin, tentacleSkin, menuTitle,
            background, playerDeath, enemyDeath, inkSkin, healthUpgrade, inkBottleSkin, healthBar, damageUpgrade,
            healthWord, waveWord, playButton, instructionsButton, quitButton, gameOverWords;
        Bullet[] bullets;                       // Array of bullets
        Vector2 titleLoc;                       // Vector2D for the title location

        KeyboardState previousKbs;              // KeyboardState for the previous key - used for player movement
        KeyboardState previousKbs2;             // KeyboardState for the previous key - used for the menu and pausing

        int width, height;                      // Width and height of the window

        // These are based on the gameTime
        int animation3Frame;                    // Multiplier value for a 3 frame animation
        int animation2Frame;                    // Multiplier value for a 2 frame animation                   
        int animation5Frame;                    // Multiplier value for a 5 frame animation

        // The playerFrameDelayCounter / playerTimeDelayNumber = which frame to display
        int playerFrameDelayCounter;            // The counter for the amount of time to delay the frame for the player animation
        int playerTimeDelayNumber;              // The amount of time that the frame for the player animation will display before changing

        int rowInPlayerDeath;                   // Int to keep track of what row of the playerDeath sprite sheet we are in
        int playerDeath7FrameCounter;           // Multiplier value for the 7 frame animation of playerDeath - this only starts once the game over screen appears
        // and is thus independent of the gametime

        double timePerFrame = 100;              // The divisor for the gameTime (which is measured in milliseconds) - gets the gameTime in seconds
        int numFrames;                          // The number of frames in the sprite sheet
        int framesElapsed;                      // How many frames have elapsed

        int waveSize;                           // The size of the wave
        int waveNumber;                         // The number of the wave
        int numEnemiesInList;                   // The number of enemies left in the list
        int typeEnemy;                          // The type of enemy - 0 = slug, 1 = tentacle, 2 = octopus
        int numEnemiesOnScreen;                 // The number of enemies on the screen
        int onScreenCap;                        // The number of enemeis allowed on the screen
        int enemyIndexNum, inkIndexNum;                      // The index of the enemy associated in the List of enemies 

        bool isEmpty;                           // True if there are no enemies left in the wave
        bool HPCostIncreased;                   // Check to see if the cost for healing has increased (it increases every few waves and stays the same in between)
        bool isStill;                           // Check if the player is not moving

        Random rnd;                             // Random object
        List<Enemy> eList;                      // The List of enemies in a wave
        List<Ink> iList;

        // The states for the player
        enum PlayerState
        {
            faceForward,
            faceBackward,
            walkDown1,
            walkDown2,
            walkDown3,
            walkUp1,
            walkUp2,
            walkUp3,
            walkRight1,
            walkRight2,
            walkRight3,
            walkLeft1,
            walkLeft2,
            walkLeft3
        }

        PlayerState playerState;                // PlayerState object

        // The states for the game
        enum GameState
        {
            menu,
            pause,
            game,
            gameOver,
            instructions
        }
        Stack<GameState> gameState;             // GameState stack

        // Menu options
        enum Menu
        {
            play,
            instructions,
            quit
        }
        Menu menuChoice;                        // Menu object

        #endregion

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            //graphics.PreferredBackBufferWidth = 1800;
            //graphics.PreferredBackBufferHeight = 600;
            //graphics.IsFullScreen = true;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            rnd = new Random();
            width = graphics.GraphicsDevice.Viewport.Width;
            height = graphics.GraphicsDevice.Viewport.Height;

            rowInPlayerDeath = 0;                   // Set the row in the playerDeath spritesheet to the first row (aka 0)
            playerDeath7FrameCounter = 0;           // The playerDeath frame mutlplier (going horizontally) starts at 0
            playerFrameDelayCounter = 0;            // The amount of total time for the player to animate in any direction starts at 0
            playerTimeDelayNumber = 8;              // Each frame of the player will last for 8 frames

            waveNumber = 0;                         // The wave number starts at 0
            isEmpty = false;                        // The first wave does not start empty
            HPCostIncreased = false;                // The cost of HP has not been increased once the game starts
            isStill = true;                         // The player starts still

            p = new Player(width / 2, height / 2, width, height, waveNumber);   // The player (starts in the center of the screen, pass in the width and height of the window, pass in the wavenumber)
            bullets = new Bullet[30];                                           // You have 30 bullets


            playMenuMusic = false;                  //Sets these bools to false
            playGameMusic = false;                  //So it knows when to play the music.

            waveSize = ((waveNumber * 15) / 10) + 10;                           // The wave size starts at 10
            numEnemiesInList = 0;                                               // There are 0 enemies in the List at first
            numEnemiesOnScreen = 0;                                             // There are no enemies on the screen at first
            onScreenCap = 5;                                                    // The max number of enemies that can be on the screen starts at 5
            enemyIndexNum = -1;
            inkIndexNum = -1;                                                   // The enemy index starts at -1
            eList = new List<Enemy>();                                          // Instantiate the enemy list
            iList = new List<Ink>();                                       

            titleLoc = new Vector2(153, 25);                                    // Set the title location
            gameState = new Stack<GameState>();                                 // Instantiate the gameState
            gameState.Push(GameState.menu);                                     // The first gameState in the stack is the menu
            menuChoice = new Menu();                                            // Instantiate the menuChoice
            menuChoice = Menu.play;                                             // The first menuChoice highlighted is play

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            playerSkin = Content.Load<Texture2D>("PlayerStuff/Player");
            bulletSkin = Content.Load<Texture2D>("PlayerStuff/BulletSkinPNG");
            font = Content.Load<SpriteFont>("Arial");
            octopusSkin = Content.Load<Texture2D>("EnemySpriteSheets/OctopusSpriteSheet");
            slugSkin = Content.Load<Texture2D>("EnemySpriteSheets/Slug");
            tentacleSkin = Content.Load<Texture2D>("EnemySpriteSheets/Tentacle");
            menuTitle = Content.Load<Texture2D>("MenuStuff/MenuTitle");
            playButton = Content.Load<Texture2D>("MenuStuff/playButton");
            instructionsButton = Content.Load<Texture2D>("MenuStuff/instructionsButton");
            quitButton = Content.Load<Texture2D>("MenuStuff/quitButton");
            gameOverWords = Content.Load<Texture2D>("MenuStuff/gameOverWords");
            background = Content.Load<Texture2D>("Background");
            playerDeath = Content.Load<Texture2D>("PlayerStuff/PlayerDeath");
            inkSkin = Content.Load<Texture2D>("DropSkin");
            enemyDeath = Content.Load<Texture2D>("EnemySpriteSheets/EnemyDeath");
            healthUpgrade = Content.Load<Texture2D>("HUDStuff/heart");
            inkBottleSkin = Content.Load<Texture2D>("HUDStuff/InkBottle");
            healthBar = Content.Load<Texture2D>("HUDStuff/HealthBar");
            damageUpgrade = Content.Load<Texture2D>("HUDStuff/damageUp");
            healthWord = Content.Load<Texture2D>("HUDStuff/healthWord");
            waveWord = Content.Load<Texture2D>("HUDStuff/waveWord");
                        
            gameMusic = Content.Load<SoundEffect>("game");
            menuMusic = Content.Load<SoundEffect>("menu");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            if (menuMusicInstance == null)
            {
                gameMusicInstance = gameMusic.CreateInstance(); //These things are necessary for looping.
                menuMusicInstance = menuMusic.CreateInstance();

                menuMusicInstance.IsLooped = true;
                gameMusicInstance.IsLooped = true;
            }
            // TODO: Add your update logic here
            UpdatePlayerFrameDelayCounter();
            HandleInput(gameTime);

            // If the game state is not paused, check for other gameStates
            if (gameState.Peek() != GameState.pause)
            {
                // Update the menu when at the menu
                if (gameState.Peek() == GameState.menu)
                {
                    UpdateMenu(gameTime);
                    if (!playMenuMusic)
                    {
                        if (playGameMusic)
                        {
                            gameMusicInstance.Stop();
                        }
                        menuMusicInstance.Play();
                        playMenuMusic = true;
                        playGameMusic = false;

                    }
                }

                // Update the game when in the game
                if (gameState.Peek() == GameState.game)
                {
                    if (!playGameMusic)
                    {
                        menuMusicInstance.Stop();
                        gameMusicInstance.Play();
                        playGameMusic = true;
                        playMenuMusic = false;
                    }
                    HandleWave();
                    UpdateEnemy(gameTime);
                    UpdateBullets();
                    for (int x = 0; x < iList.Count; x++)
                    {
                        UpdateInk(iList[x]);
                    }
                    CheckBullets();
                    GameOver();
                    
                }

                // Update the player dying animation during the game over screen
                if (gameState.Peek() == GameState.gameOver)
                {
                    UpdatePlayerDeath();
                    if (playGameMusic)
                    {
                        gameMusicInstance.Stop();
                    }
                    playGameMusic = false;
                }
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {

            if (gameState.Count().Equals(0))
                Environment.Exit(0);

            spriteBatch.Begin();

            spriteBatch.Draw(background, new Vector2(0, 0), Color.White);                       // Draw the background

            spriteBatch.End();

            // Draw the appropriate things depending on the gameState
            switch (gameState.Peek())
            {
                #region Game
                case GameState.game:

                    // TODO: Add your drawing code here                    
                    foreach (Ink i in iList)
                    {
                        if (i != null)
                        {
                            DrawInk(i);
                        }
                        
                    }
                    DrawPlayer(); 
                    foreach (Enemy enemy in eList)
                    {
                        if (enemy != null)
                            DrawEnemy(enemy);
                    }
                    DrawBullet();
                    DrawHUD();
                    break;
                #endregion
                #region Menu
                case GameState.menu:
                    DrawMenu();
                    break;
                #endregion
                #region Game Over
                case GameState.gameOver:
                    DrawGameOver();
                    DrawPlayerDead();
                    break;
                #endregion
                #region Instructions
                case GameState.instructions:
                    DrawInstructions();
                    break;
                #endregion
                #region Pause
                case GameState.pause:
                    DrawPause();
                    break;
                #endregion
            }
            base.Draw(gameTime);
        }

        #region Update methods
        /// <summary>
        /// Handles changes in the game from player input
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public void HandleInput(GameTime gameTime)
        {
            KeyboardState kbs = Keyboard.GetState();            // Set up a keyboard state object to check for the current keyboard state
            // Handling input while in game
            if (gameState.Peek() == GameState.game)
            {

                // Moving
                UpdatePlayer(kbs);

                // Shooting
                bullets = p.getShootInput();

                // Upgrades
                p.getUpgradeInput();

                // Pausing
                if (kbs.IsKeyDown(Keys.P) && previousKbs2.IsKeyUp(Keys.P))
                    gameState.Push(GameState.pause);
            }
            // check if the game state is currently in the menu
            if (gameState.Peek() == GameState.menu)
            {
                // go to the menu option that is currently selected
                if (kbs.IsKeyDown(Keys.Enter) && previousKbs2.IsKeyUp(Keys.Enter))
                {
                    switch (menuChoice)
                    {
                        case Menu.play:
                            gameState.Push(GameState.game);
                            break;
                        case Menu.instructions:
                            gameState.Push(GameState.instructions);
                            break;
                        case Menu.quit:
                            Environment.Exit(0);
                            //gameState.Pop();
                            break;
                    }
                }
                // move through the menu
                // Right
                else if (kbs.IsKeyDown(Keys.D) && previousKbs2.IsKeyUp(Keys.D))
                {
                    if (menuChoice == Menu.quit)
                        menuChoice = Menu.play;
                    else
                        menuChoice++;
                }
                // Left
                else if (kbs.IsKeyDown(Keys.A) && previousKbs2.IsKeyUp(Keys.A))
                {
                    if (menuChoice == Menu.play)
                        menuChoice = Menu.quit;
                    else
                        menuChoice--;
                }
            }
            // go to the previous game state
            if (kbs.IsKeyDown(Keys.Back) && previousKbs2.IsKeyUp(Keys.Back))
                gameState.Pop();

            // If the player presses 'Enter' on the game over screen, reset all values and go back to the menu
            if (gameState.Peek() == GameState.gameOver)
            {
                if (kbs.IsKeyDown(Keys.Enter))
                {
                    Initialize();
                    gameState.Push(GameState.menu);
                }
            }

            previousKbs2 = kbs;          // Set the previous keyboardstate to the current one
        }

        public void UpdateInk(Ink ink)
        {
            if (ink != null && !ink.UpdateTimer())
            {
                iList[ink.Index] = null;
            }

            if (ink != null && ink.BoundBox.Intersects(p.PlayerBoundBox))
            {
                p.Pickup(ink.Amount);
                iList[ink.Index] = null;
            }
        }


        #region Player stuff
        /// <summary>
        /// Keeping track of how long its been since the player started moving
        /// </summary>
        public void UpdatePlayerFrameDelayCounter()
        {
            // If the player is not moving, the counter stays at 0
            if (isStill)
                playerFrameDelayCounter = 0;
            // If the player is moving, the counter increases each frame with a max of 24 (each direction has 3 frames and each one lasts for 8 frames)
            else
            {
                playerFrameDelayCounter++;
                // Reset the counter to 0 once we reach 24
                if (playerFrameDelayCounter > 23)
                    playerFrameDelayCounter = 0;
            }
        }

        /// <summary>
        /// Check which way the player is moving (or if he/she is not moving at all)
        /// Change the playerState to determine which sprite to display
        /// </summary>
        /// <param name="kbs">The current keyboard state</param>
        public void UpdatePlayer(KeyboardState kbs)
        {
            //Movement
            // If you moved up last and are standing still (or are pressing buttons that would move you in the opposite directions at the same time)
            if (((previousKbs.IsKeyDown(Keys.S) || previousKbs.IsKeyDown(Keys.A) || previousKbs.IsKeyDown(Keys.D))
                    && !kbs.IsKeyDown(Keys.W) && !kbs.IsKeyDown(Keys.S) && !kbs.IsKeyDown(Keys.A) && !kbs.IsKeyDown(Keys.D))
                    || (kbs.IsKeyDown(Keys.A) && previousKbs.IsKeyDown(Keys.D))
                    || (kbs.IsKeyDown(Keys.D) && previousKbs.IsKeyDown(Keys.A))
                    || (kbs.IsKeyDown(Keys.W) && previousKbs.IsKeyDown(Keys.S))
                    || (kbs.IsKeyDown(Keys.S) && previousKbs.IsKeyDown(Keys.W)))
            {
                playerState = PlayerState.faceForward;
                isStill = true;
            }
            
            // If you moved left, right, or down last and are standing still
            else if (previousKbs.IsKeyDown(Keys.W) && !kbs.IsKeyDown(Keys.W) && !kbs.IsKeyDown(Keys.S) && !kbs.IsKeyDown(Keys.A) && !kbs.IsKeyDown(Keys.D))
            {
                playerState = PlayerState.faceBackward;
                isStill = true;
            }

            else
            {
                // Moving upward
                // The second frame (comes from first frame)
                if (kbs.IsKeyDown(Keys.W) && playerState == PlayerState.walkUp1)
                {
                    isStill = false;
                    p.Move(3);
                    // The total frames for a full animation in one direction / the number of frames that this frame of the player will stay on the screen
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 1)
                        playerState = PlayerState.walkUp2;
                }
                // The third frame (comes from second frame)
                else if (kbs.IsKeyDown(Keys.W) && playerState == PlayerState.walkUp2)
                {
                    isStill = false;
                    p.Move(3);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 2)
                        playerState = PlayerState.walkUp3;
                }
                // The first frame (comes from any except the second frame or itself)
                else if (kbs.IsKeyDown(Keys.W))
                {
                    // If the previous key was not W, reset the counter
                    if (!previousKbs.IsKeyDown(Keys.W))
                        playerFrameDelayCounter = 0;
                    isStill = false;
                    p.Move(3);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 0)
                        playerState = PlayerState.walkUp1;
                }


                // Moving downward
                // The second frame (comes from first frame)
                if (kbs.IsKeyDown(Keys.S) && playerState == PlayerState.walkDown1)
                {
                    isStill = false;
                    p.Move(4);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 1)
                        playerState = PlayerState.walkDown2;
                }
                // The third frame (comes from second frame)
                else if (kbs.IsKeyDown(Keys.S) && playerState == PlayerState.walkDown2)
                {
                    isStill = false;
                    p.Move(4);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 2)
                        playerState = PlayerState.walkDown3;
                }
                // The first frame (comes from any except the second frame or itself)
                else if (kbs.IsKeyDown(Keys.S))
                {
                    // If the previous key was not S, reset the counter
                    if (!previousKbs.IsKeyDown(Keys.S))
                        playerFrameDelayCounter = 0;
                    isStill = false;
                    p.Move(4);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 0)
                        playerState = PlayerState.walkDown1;
                }


                // Moving left
                // The second frame (comes from first frame)
                if (kbs.IsKeyDown(Keys.A) && playerState == PlayerState.walkLeft1)
                {
                    isStill = false;
                    p.Move(1);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 1)
                        playerState = PlayerState.walkLeft2;
                }
                // The third frame (comes from second frame)
                else if (kbs.IsKeyDown(Keys.A) && playerState == PlayerState.walkLeft2)
                {
                    isStill = false;
                    p.Move(1);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 2)
                        playerState = PlayerState.walkLeft3;
                }
                // The first frame (comes from any except the second frame or itself)
                else if (kbs.IsKeyDown(Keys.A))
                {
                    // If the previous key was not A, reset the counter
                    if (!previousKbs.IsKeyDown(Keys.A))
                        playerFrameDelayCounter = 0;
                    isStill = false;
                    p.Move(1);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 0)
                        playerState = PlayerState.walkLeft1;
                }


                // Moving right
                // The second frame (comes from first frame)
                if (kbs.IsKeyDown(Keys.D) && playerState == PlayerState.walkRight1)
                {
                    isStill = false;
                    p.Move(2);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 1)
                        playerState = PlayerState.walkRight2;
                }
                // The third frame (comes from second frame)
                else if (kbs.IsKeyDown(Keys.D) && playerState == PlayerState.walkRight2)
                {
                    isStill = false;
                    p.Move(2);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 2)
                        playerState = PlayerState.walkRight3;
                }
                // The first frame (comes from any except the second frame or itself)
                else if (kbs.IsKeyDown(Keys.D))
                {
                    // If the previous key was not D, reset the counter
                    if (!previousKbs.IsKeyDown(Keys.D))
                        playerFrameDelayCounter = 0;
                    isStill = false;
                    p.Move(2);
                    if ((playerFrameDelayCounter / playerTimeDelayNumber) == 0)
                        playerState = PlayerState.walkRight1;
                }
            }
            previousKbs = kbs;
        }

        /// <summary>
        /// Update the playerDeath counter (to determine what sprite to display)
        /// </summary>
        public void UpdatePlayerDeath()
        {
            playerDeath7FrameCounter++;
            // If it's greater than 28 set the counter back to 0. If the row is above 2 (outside of the sprite sheet), skip this
            if (playerDeath7FrameCounter > 28 && rowInPlayerDeath < 3)
            {
                playerDeath7FrameCounter = 0;
                rowInPlayerDeath++;             // Increment the row in the sprite sheet so that we can display the next row
            }
        }

        #endregion

        #region Enemy stuff

        /// <summary>
        /// Updates the sprite for the enemy, the movement, and the damage
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public void UpdateEnemy(GameTime gameTime)
        {
            // Calculate the frame to draw based on the time
            //  - The variable "frame" will contain either 1, 2 or 3 (the "walking" frames)
            //  - Frame 0 is the "standing" frame
            foreach (Enemy enemy in eList)
            {
                if (enemy != null)
                {
                    framesElapsed = (int)(gameTime.TotalGameTime.TotalMilliseconds / timePerFrame);
                    // If the enemy is an octopus (it has 3 frames and thus is different from the slug and the tentacle)
                    if (enemy.Type == "O")
                    {
                        numFrames = 3;
                        animation3Frame = framesElapsed % numFrames;
                    }
                    // If the enemy is a slug or a tentacle (they have 2 frames)
                    if (enemy.Type == "S" || enemy.Type == "T")
                    {
                        numFrames = 2;
                        animation2Frame = framesElapsed % numFrames;
                    }

                    // The enemy moves closer to the player (roughly towards the player's center)
                    enemy.Move(p.Vect_X + 15, p.Vect_Y + 40);

                    // Deal damage if the enemy is over the player, but delay it
                    if (enemy.Attack() && p.PlayerBoundBox.Intersects(enemy.EnemyBoundBox))
                    {
                        p.TakeDamage(enemy.Damage);
                    }
                    enemy.TimerCounter();       // Update the delay counter for the enemy dealing damage
                }
            }

        }

        /// <summary>
        /// Adds an enemy to a wave
        /// </summary>
        public void AddEnemy()
        {
            // If the wave is less than 3 (for the first 3 waves) - only have slugs
            // If the wave is between waves 3 and 5 - have slugs and tentacles
            // If the waev is 5 or higher - have all enemies
            if (waveNumber < 3)
                typeEnemy = 0;
            else if (waveNumber > 2 && waveNumber < 5)
                typeEnemy = rnd.Next(0, 2);
            else if (waveNumber > 4)
                typeEnemy = rnd.Next(0, 3);

            // If the size of the List is less than the wave size, add enemies to the end of the list
            if (eList.Count < waveSize)
            {
                enemyIndexNum++;            // Increase the index number
                if (typeEnemy == 0)
                    eList.Add(new EnemySlug(waveNumber, width, height, enemyIndexNum));
                if (typeEnemy == 1)
                    eList.Add(new EnemyTentacle(waveNumber, width, height, enemyIndexNum));
                if (typeEnemy == 2)
                    eList.Add(new EnemyOctopus(waveNumber, width, height, enemyIndexNum));
            }
            // If the size of the list is not less than the wave size, replace any nulls with new enemies
            else
            {
                for (int i = 0; i < waveSize; i++)
                {
                    if (eList[i] == null)
                    {
                        if (typeEnemy == 0)
                            eList[i] = new EnemySlug(waveNumber, width, height, i);
                        if (typeEnemy == 1)
                            eList[i] = new EnemyTentacle(waveNumber, width, height, i);
                        if (typeEnemy == 2)
                            eList[i] = new EnemyOctopus(waveNumber, width, height, i);
                        break;      // Add only 1 enemy
                    }
                }
            }
        }

        /// <summary>
        /// Removes an enemy from the wave
        /// </summary>
        /// <param name="e">The specific enemy being removed</param>
        public void RemoveEnemy(Enemy e)
        {
            inkIndexNum++;
            iList.Add(new Ink(e.Drop(), eList[e.Index].XLoc, eList[e.Index].YLoc, inkIndexNum));
            eList[e.Index] = null;      // Set it equal to null in the list
            numEnemiesOnScreen--;       // Decrement the number of enemies on the scree
        }

        /// <summary>
        /// Handles the wave
        /// </summary>
        public void HandleWave()
        {
            // Increase the cost of HP every 5 waves once
            if (!HPCostIncreased && (waveNumber + 1) % 5 == 0)
            {
                p.InkCost3 += 10;
                HPCostIncreased = true;
            }

            // Check if eList is null
            if (eList.Count > 0)
            {
                foreach (Enemy e in eList)
                {
                    if (e != null)
                        isEmpty = false;
                    else if (e == null)
                        isEmpty = true;
                }
            }

            // If eList is null, there are no enemies on the screen, and the number of enemies (alive or dead) in the list is equal to the wave size
            // Reset the list, the number of enemies on the screen, the number of enemies in the list, increment the wave number, increase the wave size (for the next wave)
            // and increase the max number of enemies allowed on the screen at once
            if (isEmpty && numEnemiesOnScreen == 0 && numEnemiesInList == waveSize)
            {
                HPCostIncreased = false;
                numEnemiesOnScreen = 0;
                waveNumber++;
                waveSize = (waveNumber * 2) + 10;
                numEnemiesInList = 0;
                if((waveNumber + 1) % 5 == 0)
                    onScreenCap += waveNumber / 5;
            }
            // If still in the current wave and the number of enemies on the screen is lower than the cap, add enemies, increase the number of enemies on the screen, and increase
            // the number of enemies that have been in the list
            else if (numEnemiesInList < waveSize && numEnemiesOnScreen < onScreenCap)
            {
                AddEnemy();
                numEnemiesOnScreen++;
                numEnemiesInList++;
            }
        }

        #endregion

        #region Bullet stuff
        /// <summary>
        /// Move bullets if they are on the screen
        /// </summary>
        public void UpdateBullets()
        {
            foreach (Bullet b in bullets)
            {
                if (b != null)
                    b.Move();
            }
        }

        /// <summary>
        /// Collision detection between bullets and enemies
        /// </summary>
        public void CheckBullets()
        {
            foreach (Bullet b in bullets)
            {
                if (b != null)
                {
                    if (b.CheckBullet())
                    {
                        p.RemoveBullet(b.Index);
                        bullets = p.Bullets;
                    }
                    for (int i = 0; i < eList.Count; i++)
                    {
                        if (eList[i] != null && b.BulletBoundBox.Intersects(eList[i].EnemyBoundBox))
                        {
                            p.RemoveBullet(b.Index);
                            bullets = p.Bullets;
                            if (eList[i].TakeDamage(b.Damage))
                            {
                                RemoveEnemy(eList[i]);
                            }
                        }
                    }
                }
            }
        }

        #endregion


        /// <summary>
        /// Update the menu (the title really)
        /// This is used to determine what frame to show
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public void UpdateMenu(GameTime gameTime)
        {
            framesElapsed = (int)(gameTime.TotalGameTime.TotalMilliseconds / timePerFrame);
            numFrames = 5;
            animation5Frame = framesElapsed % numFrames;
        }

        #endregion

        #region Draw Methods

        /// <summary>
        /// Draws an enemy
        /// </summary>
        /// <param name="enemy">The enemy to draw</param>
        public void DrawEnemy(Enemy enemy)
        {
            spriteBatch.Begin();

            // Draw a particular enemy depending on its type - O: Octopus, S: Slug, T: Tentacle
            if (enemy.Type == "O")
                spriteBatch.Draw(octopusSkin, enemy.Loc, new Rectangle(animation3Frame * enemy.width, 0, enemy.width, enemy.height), Color.White);
            if (enemy.Type == "S")
                spriteBatch.Draw(slugSkin, enemy.Loc, new Rectangle(animation2Frame * enemy.width, 0, enemy.width, enemy.height), Color.White);
            if (enemy.Type == "T")
                spriteBatch.Draw(tentacleSkin, enemy.Loc, new Rectangle(animation2Frame * enemy.width, 0, enemy.width, enemy.height), Color.White);

            spriteBatch.End();
        }

        public void DrawInk(Ink ink)
        {
            spriteBatch.Begin();

            spriteBatch.Draw(inkSkin, ink.Loc, Color.White);

            spriteBatch.End();
        }

        #region Player stuff

        /// <summary>
        /// Draws the player
        /// </summary>
        public void DrawPlayer()
        {
            spriteBatch.Begin();

            // Finite state machine for the sprite sheet
            switch (playerState)
            {
                case PlayerState.faceBackward:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(0, p._HEIGHT, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.faceForward:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH, 0, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkDown1:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(0, 0, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkDown2:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH * 3, 0, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkDown3:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH * 2, 0, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkUp1:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH, p._HEIGHT, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkUp2:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH * 2, p._HEIGHT, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkUp3:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH * 3, p._HEIGHT, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkLeft1:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(0, p._HEIGHT * 2, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkLeft2:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH, p._HEIGHT * 2, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkLeft3:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH * 2, p._HEIGHT * 2, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkRight1:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(0, p._HEIGHT * 3, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkRight2:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH, p._HEIGHT * 3, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                case PlayerState.walkRight3:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH * 2, p._HEIGHT * 3, p._WIDTH, p._HEIGHT), Color.White);
                    break;
                default:
                    spriteBatch.Draw(playerSkin, p.Vect, new Rectangle(p._WIDTH, 0, p._WIDTH, p._HEIGHT), Color.White);
                    break;
            }

            spriteBatch.End();
        }

        /// <summary>
        /// Draw the animation for the player dying
        /// </summary>
        public void DrawPlayerDead()
        {
            spriteBatch.Begin();

            // Run through each row (the rowInPlayerDeath value will increment in UpdatePlayerDeath())
            if (rowInPlayerDeath == 0)
                spriteBatch.Draw(playerDeath, new Vector2(365, 320), new Rectangle((playerDeath7FrameCounter / 4) * p._WIDTH, 0, p._WIDTH, p._HEIGHT), Color.White);
            if (rowInPlayerDeath == 1)
                spriteBatch.Draw(playerDeath, new Vector2(365, 320), new Rectangle((playerDeath7FrameCounter / 4) * p._WIDTH, p._HEIGHT, p._WIDTH, p._HEIGHT), Color.White);
            if (rowInPlayerDeath == 2)
                spriteBatch.Draw(playerDeath, new Vector2(365, 320), new Rectangle((playerDeath7FrameCounter / 4) * p._WIDTH, p._HEIGHT * 2, p._WIDTH, p._HEIGHT), Color.White);

            spriteBatch.End();
        }

        #endregion

        #region Menu stuff

        /// <summary>
        /// Draws the Menu
        /// </summary>
        public void DrawMenu()
        {
            spriteBatch.Begin();

            // Draws the correct frame for the title
            spriteBatch.Draw(menuTitle, titleLoc, new Rectangle(0, animation5Frame * 300, 500, 300), Color.White);

            // check what option in the menu is currentlty selected
            if (menuChoice != Menu.play)
                spriteBatch.Draw(playButton, new Vector2(120, 300), Color.Black);
            if (menuChoice != Menu.instructions)
                spriteBatch.Draw(instructionsButton, new Vector2(280, 300), Color.Black);
            if (menuChoice != Menu.quit)
                spriteBatch.Draw(quitButton, new Vector2(600, 300), Color.Black);

            // Highlighted the menu choice that is being hovered over in red
            switch (menuChoice)
            {
                case Menu.play: spriteBatch.Draw(playButton, new Vector2(120, 300), Color.Gold);
                    break;
                case Menu.instructions: spriteBatch.Draw(instructionsButton, new Vector2(280, 300), Color.Gold);
                    break;
                case Menu.quit: spriteBatch.Draw(quitButton, new Vector2(600, 300), Color.Gold);
                    break;
            }

            // Menu instructions
            spriteBatch.DrawString(font, "Enter to select \n A and D to go left and right \n backspace to go back", new Vector2(50, 370), Color.Black);

            spriteBatch.End();
        }

        /// <summary>
        /// Draws the Instructions
        /// </summary>
        public void DrawInstructions()
        {
            spriteBatch.Begin();

            spriteBatch.DrawString(font, "INSTRUCTIONS", new Vector2(250, 100), Color.Black);

            spriteBatch.DrawString(font, "Press W, A, S or D to move around \nPress the arrow keys to shoot\nPress P to pause the game\nPick up Ink that is dropped by enemies"
                + "\nPress Q to upgrade your damage (Costs Ink) \nPress E to recover health (Costs Ink)", new Vector2(250, 150), Color.Black);

            spriteBatch.DrawString(font, "Enter to select \n A and D to go left and right \n backspace to go back", new Vector2(50, 370), Color.Black);

            spriteBatch.End();
        }

        /// <summary>
        /// Draws the gameover screen
        /// </summary>
        public void DrawGameOver()
        {
            spriteBatch.Begin();

            GraphicsDevice.Clear(Color.DarkRed);

            spriteBatch.Draw(gameOverWords, new Vector2(200, 150), Color.Black);

            spriteBatch.DrawString(font, "Press Enter to continue", new Vector2(300, 280), Color.Black);

            spriteBatch.End();
        }

        /// <summary>
        /// Draws the pause screen
        /// </summary>
        public void DrawPause()
        {
            spriteBatch.Begin();

            GraphicsDevice.Clear(Color.White);

            spriteBatch.Draw(background, new Vector2(0, 0), Color.White);

            spriteBatch.DrawString(font, "PAUSED", new Vector2(360, 220), Color.Black);

            spriteBatch.End();
        }

        #endregion

        /// <summary>
        /// Draws the HUD
        /// </summary>
        public void DrawHUD()
        {
            spriteBatch.Begin();
            // Draws the health and its value, your ink and its value, the wave number, and both upgrades and their costs
            spriteBatch.Draw(healthWord, new Vector2(0, 2), Color.White); // Change this to change with the value
            spriteBatch.Draw(healthBar, new Vector2(65, 0), new Rectangle(0, 0,p.Health * 2, 20), Color.White);
            
            spriteBatch.Draw(inkBottleSkin, new Vector2(0, 25), Color.White);
            spriteBatch.DrawString(font, ": " + p.Ink, new Vector2(43, 45), Color.Black);

            spriteBatch.Draw(waveWord, new Vector2(0, 82), Color.White);
            spriteBatch.DrawString(font, "" + (waveNumber + 1), new Vector2(55, 79), Color.Black);

            spriteBatch.Draw(damageUpgrade, new Vector2(width - 300, 2), Color.White);
            spriteBatch.DrawString(font, "(Q)", new Vector2(width - 330, 0), Color.Black);
            spriteBatch.DrawString(font, ": " + p.InkCost2 + " Ink", new Vector2(width - 278, 0), Color.Black);

            spriteBatch.Draw(healthUpgrade, new Vector2(width - 150, 2), Color.White);
            spriteBatch.DrawString(font, "(E)", new Vector2(width - 180, 0), Color.Black);
            spriteBatch.DrawString(font, ": " + p.InkCost3 + " Ink", new Vector2(width - 128, 0), Color.Black);

            spriteBatch.End();
        }

        /// <summary>
        /// Draws bullets
        /// </summary>
        public void DrawBullet()
        {
            spriteBatch.Begin();

            foreach (Bullet b in bullets)
            {
                if (b != null)
                    spriteBatch.Draw(bulletSkin, b.Vect, Color.Black);
            }


            spriteBatch.End();
        }

        #endregion

        /// <summary>
        /// Checks if the player has died
        /// Checks if the game is over
        /// </summary>
        public void GameOver()
        {
            if (p.Dead())
            {
                gameState.Push(GameState.gameOver);
            }
        }
    }
}
