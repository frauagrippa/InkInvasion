﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InkInvasion
{
    class EnemySlug : Enemy
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="waveNumber">The current wave number</param>
        /// <param name="windowWidth">The width of the window</param>
        /// <param name="windowHeight">The height of the window</param>
        /// <param name="theIndex">The index of the enemy in the List of enemies (in the Game1 class)</param>
        public EnemySlug(int waveNumber, int windowWidth, int windowHeight, int theIndex)
            : base(waveNumber, windowWidth, windowHeight, theIndex)
        {
            index = theIndex;
            type = "S";                                         // This enemy is a slug
            waveCounter = waveNumber;
            
            EnemySpawnLocation(windowWidth, windowHeight);

            health = 20 + (10 * (waveNumber / 4));              // Increase the slug's health by 10 every 4 waves

            // Change the slug's speed starting 5 waves after slugs first appear
            if (waveNumber > 5)
                moveSpeed = rnd.Next(1, 3);                     // Speed between 1 and 2
            else
                moveSpeed = 1;                                  // Default speed of 1

            damage = 3;                                         // Slug deals 3 damage
            enemyBoundBox = new Rectangle((int)XLoc, (int)YLoc, WIDTH, HEIGHT);

            attackTimer = 0;                                    // They start with not delay on attack
        }

        /// <summary>
        /// Override the abstract Move from enemy
        /// </summary>
        /// <param name="PlayerX">The player's x-value</param>
        /// <param name="PlayerY">The player's y-value</param>
        public override void Move(float PlayerX, float PlayerY)
        {
            // The distances from the player
            xDis = XLoc - PlayerX;
            yDis = YLoc - PlayerY;

            rotationAngle = (float)Math.Atan2(yDis, xDis);              // Find the angle to fluctuate on

            XLoc -= (float)(moveSpeed * Math.Cos(rotationAngle));       // Fluctuate the x value of the enemy purely based on the cos of the rotationAngle
            YLoc -= (float)(moveSpeed * Math.Sin(rotationAngle));       // Fluctuate the y value of the enemy purely based on the sin of the rotationAngle

            // Fluctuate the y value of the enemy
            enemyBoundBox.X = (int)XLoc;
            enemyBoundBox.Y = (int)YLoc;
        }

        /// <summary>
        /// Deteremins how much ink a slug drops
        /// </summary>
        /// <returns>The amount the slug drops</returns>
        public override int Drop()
        {
            return 1 + (waveCounter / 7);      // Base drop of 1, Increase the amount dropped by 1 every 7 waves
        }
    }
}
