﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;

namespace InkInvasion
{
    public class Ink
    {
        #region Attributes

        private Vector2 loc;
        private float xLoc, yLoc;
        private const int HEIGHT = 17;
        private const int WIDTH = 17;
        private Rectangle boundBox;
        private int DespawnTimer = 0;
        private int amount;
        private int index;

        #endregion  

        #region Accessors and Mutators

        public float XLoc
        {
            get { return xLoc; }
            set { xLoc = value; }
        }
        public float YLoc
        {
            get { return yLoc; }
            set { yLoc = value; }
        }
        public Vector2 Loc
        {
            get { return loc; }
            set { loc = value; }
        }
        public int Amount
        {
            get { return amount; }
            set { amount = value; }
        }
        public int Index
        {
            get { return index; }
            set { index = value; }
        }
        public Rectangle BoundBox
        {
            get { return boundBox; }
        }
        public int height
        {
            get { return HEIGHT; }
        }

        public int width
        {
            get { return WIDTH; }
        }

        #endregion 

        public Ink(int inkAmount, float x, float y, int theIndex)
        {
            xLoc = x;
            yLoc = y;
            loc = new Vector2(xLoc, yLoc);

            index = theIndex;

            amount = inkAmount;

            boundBox = new Rectangle((int) XLoc, (int) YLoc, WIDTH, HEIGHT);
        }

        public bool UpdateTimer()
        {
            if (DespawnTimer < 350)
            {
                DespawnTimer++;
                return true;
            }
            else
            {
                return false;
            }
        }

        public int pickedUp()
        {
            return amount;
        }

    }
}
