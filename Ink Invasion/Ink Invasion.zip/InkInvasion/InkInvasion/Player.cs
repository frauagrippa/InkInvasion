﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace InkInvasion
{
    class Player
    {
        #region Attributes

        private int health, _x, _y, damage, ink;
        private const int WIDTH = 60;
        private const int HEIGHT = 80;
        //private int inkCost1 = 10;
        private int inkCost2 = 40;
        private int inkCost3 = 20;
        private int numTimesDamageIncreased;
        private const int DAMAGE_INCREASE = 5;
        private const int HEALTH_INCREASE = 20;
        private const int MAX_HEALTH = 100;
        private const int SPEED = 3;
        private Vector2 vect;
        private const string imageLocation = "PlayerSkinPNG";  //this will be changed when we are doing bitmaps
        private Texture2D playerSkin;
        private int maxNumOfBullets;
        private Bullet[] bullets;
        private int bulletCounter;
        private int sWidth, sHeight;
        private Rectangle playerBoundBox;
        private char pressedUpgrade = 'a';
        private char pressedShoot = 'a';
        private bool isDead;
        private int waveCounter;

        #endregion

        #region Accessors/Mutators

        /*public int InkCost1
        {
            get { return inkCost1; }
            set { inkCost1 = value; }
        }*/

        public int InkCost2
        {
            get { return inkCost2; }
            set { inkCost2 = value; }
        }

        public int InkCost3
        {
            get { return inkCost3; }
            set { inkCost3 = value; }
        }

        public Rectangle PlayerBoundBox
        {
            get { return playerBoundBox; }
        }

        public int _HEIGHT
        {
            get { return HEIGHT; }
        }

        public int _WIDTH
        {
            get { return WIDTH; }
        }

        public int BulletCounter
        {
            get { return bulletCounter; }
            set { bulletCounter = value; }
        }

        public Bullet[] Bullets
        {
            get { return bullets; }
            set { bullets = value; }
        }

        public int MaxNumOfBullets
        {
            get { return maxNumOfBullets; }
            set { maxNumOfBullets = value; }
        }

        public Texture2D PlayerSkin
        {
            get { return playerSkin; }
            set { playerSkin = value; }
        }

        public Vector2 Vect
        {
            get { return vect; }
            set { vect = value; }
        }

        public float Vect_X
        {
            get { return vect.X; }
            set { vect.X = value; }
        }

        public float Vect_Y
        {
            get { return vect.Y; }
            set { vect.Y = value; }
        }

        public string ImageLocation
        {
            get { return imageLocation; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int Damage
        {
            get { return damage; }
            set { damage = value; }
        }

        public int Ink
        {
            get { return ink; }
            set { ink = value; }
        }

        public int _X
        {
            get { return _x; }
            set { _x = value; }
        }

        public int _Y
        {
            get { return _y; }
            set { _y = value; }
        }

        public bool IsDead
        {
            get { return isDead; }
            set { isDead = value; }
        }

#endregion

        #region Methods

        public Player(int x, int y, int w, int h, int waveNumber)
        {
            sWidth = w;
            sHeight = h;
            bulletCounter = 0;
            _X = x;
            _Y = y;
            Vect = new Vector2(_X, _Y);
            Health = 100;
            Damage = 10;
            MaxNumOfBullets = 30;
            Bullets = new Bullet[MaxNumOfBullets];
            playerBoundBox = new Rectangle((int) vect.X, (int) vect.Y, WIDTH, HEIGHT);
            ink = 0; //Change damage/ink/health when we have a better understanding of the gameplay
            waveCounter = waveNumber;
            isDead = false;
            numTimesDamageIncreased = 0;
        }

        /// <summary>
        /// handles movement for the player
        /// </summary>
        /// <param name="key">what key is being pressed</param>
        public void Move(int key)
        {
            switch (key)
            {
                case 1: Vect_X -= SPEED; playerBoundBox.X = (int) Vect_X; CheckBounds(); break; //left
                case 2: Vect_X += SPEED; playerBoundBox.X = (int) Vect_X; CheckBounds(); break; //right
                case 3: Vect_Y -= SPEED; playerBoundBox.Y = (int) Vect_Y; CheckBounds(); break; //up
                case 4: Vect_Y += SPEED; playerBoundBox.Y = (int) Vect_Y; CheckBounds(); break; //down
                default: break;
            }
        }

        /// <summary>
        /// takes in keyboard input and shoots bullets in that direction
        /// </summary>
        /// <returns>the array of bullets that the player is shooting</returns>
        public Bullet[] getShootInput()
        {
            KeyboardState kbs = Keyboard.GetState();

            //if (previousKbs.IsKeyUp(Keys.Space) && kbs.IsKeyDown(Keys.Space)) p.Shoot(); bullets = p.Bullets;
            //Pressed
            if (kbs.IsKeyDown(Keys.Up))
            {
                pressedShoot = 'u';
            }
            if (kbs.IsKeyDown(Keys.Down))
            {
                pressedShoot ='d';
            }
            if (kbs.IsKeyDown(Keys.Left))
            {
                pressedShoot = 'l';
            }
            if (kbs.IsKeyDown(Keys.Right))
            {
                pressedShoot = 'r';
            }
            //Released
            if (pressedShoot == 'u' && kbs.IsKeyUp(Keys.Up))
            {
                Shoot(1);
                pressedShoot = 'a';
            }
            if (pressedShoot == 'd' && kbs.IsKeyUp(Keys.Down))
            {
                Shoot(2);
                pressedShoot = 'a';
            }
            if (pressedShoot == 'l' && kbs.IsKeyUp(Keys.Left))
            {
                Shoot(3);
                pressedShoot = 'a';
            }
            if (pressedShoot == 'r' && kbs.IsKeyUp(Keys.Right))
            {
                Shoot(4);
                pressedShoot = 'a';
            }
            return Bullets;
        }

        /// <summary>
        /// actually shoots the bullet
        /// </summary>
        /// <param name="whichDirection">the direction in which the bullet is being shot in</param>
        public void Shoot(int whichDirection)
        {
            if (BulletCounter < MaxNumOfBullets)
            {
                int j = MaxNumOfBullets + 1;
                int i = 0;

                do
                {
                    if (Bullets[i] == null)
                    {
                        j = i;
                    }

                    i++;

                } while (j == MaxNumOfBullets + 1 && i < MaxNumOfBullets +1);

                Bullets[j] = new Bullet(j, Damage, Vect_X + 25, Vect_Y + 50, whichDirection, sWidth, sHeight);
                BulletCounter++;
            }
        }

        /// <summary>
        /// remove bullets that exit the screen/hit an enemy
        /// </summary>
        /// <param name="i">the bullet in the array that needs to be removed</param>
        public void RemoveBullet(int i)
        {
            Bullets[i] = null;
            BulletCounter--;
        }

        /// <summary>
        /// handles what upgrade the player wants
        /// </summary>
        public void getUpgradeInput()
        {
            KeyboardState kbs = Keyboard.GetState();
            

            //Pressed
            if (kbs.IsKeyDown(Keys.Q))
            {
                pressedUpgrade = 'd';
            }
            if (kbs.IsKeyDown(Keys.E))
            {
                pressedUpgrade = 'h';
            }
            if (kbs.IsKeyDown(Keys.D3))
            {
                pressedUpgrade = 't';
            }
            if (kbs.IsKeyDown(Keys.D4))
            {
                pressedUpgrade = 's';
            }
            //Released
            if (pressedUpgrade == 'd' && kbs.IsKeyUp(Keys.Q) && ink > 0) 
            { 
                Upgrade("d");
                pressedUpgrade = 'a';
            }
            if (pressedUpgrade == 'h' && kbs.IsKeyUp(Keys.E) && ink > 0)
            { 
                Upgrade("h");
                pressedUpgrade = 'a';
            }
            if (pressedUpgrade == 't' && kbs.IsKeyUp(Keys.D3) && ink > 0) 
            { 
                Upgrade("td");
                pressedUpgrade = 'a';
            }
            if (pressedUpgrade == 's' && kbs.IsKeyUp(Keys.D4) && ink > 0)
            {
                Upgrade("th");
                pressedUpgrade = 'a';
            }
            
        }

        /// <summary>
        /// Upgrades the player
        /// </summary>
        /// <param name="whichUpgrade">what upgrade type the player wants</param>
        public void Upgrade(string whichUpgrade)
        {
            //Damage += 5; //Will add more to this later
            if (whichUpgrade != "temp")
            {
                if (whichUpgrade == "d" && ink >= inkCost2) //damage upgrade
                {
                    if(numTimesDamageIncreased < 5)
                        numTimesDamageIncreased++;
                    damage = damage + DAMAGE_INCREASE;
                    ink = ink - inkCost2;
                    inkCost2 += 10 * numTimesDamageIncreased;
                }

                if (whichUpgrade == "h" && health < MAX_HEALTH && ink >= inkCost3) //health upgrade
                {
                    health = health + HEALTH_INCREASE;
                    if (health > MAX_HEALTH)
                    {
                        health = MAX_HEALTH;
                    }
                    ink = ink - inkCost3;
                }

                if (whichUpgrade == "td") //tower damage upgrade
                {
                    //upgrade tower damage
                }

                if (whichUpgrade == "th") //tower health upgrade
                {
                    //upgrade tower health
                }
            }
        }

        /// <summary>
        /// pick up ink
        /// </summary>
        /// <param name="iVal">the amount of ink</param>
        public void Pickup(int iVal)
        {
            Ink += iVal;
        }

        /// <summary>
        /// take damage
        /// </summary>
        /// <param name="dam">the amount of damage</param>
        /// <returns>if the player is still alive</returns>
        public bool TakeDamage(int dam)
        {
            Health -= dam;
            if (Health <= 0) return true;
            return false;
        }

        /// <summary>
        /// keeps the player on the screen
        /// </summary>
        public void CheckBounds()
        {
            if (Vect_X <= 0) { Vect_X = 0; playerBoundBox.X = (int)Vect_X; }
            if (Vect_Y <= 0) { Vect_Y = 0; playerBoundBox.Y = (int) Vect_Y; }
            if (Vect_X >= (sWidth - WIDTH)) { Vect_X = (sWidth - WIDTH); playerBoundBox.X = (int)Vect_X; }
            if (Vect_Y >= (sHeight - HEIGHT)) { Vect_Y = (sHeight - HEIGHT); playerBoundBox.Y = (int)Vect_Y; }
        }

        /// <summary>
        /// is the player dead?
        /// </summary>
        /// <returns>true if the player is dead</returns>
        public bool Dead()
        {
            if (health <= 0)
            {
                isDead = true;
                return isDead;
            }
            return false;
        }
        #endregion
    }
}
