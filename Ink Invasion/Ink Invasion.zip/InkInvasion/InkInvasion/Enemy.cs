﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;

namespace InkInvasion
{
    public abstract class Enemy
    {

        #region attributes

        private Vector2 loc;                                // The Vector for an enemy's location

        // The side that an enemy will spawn from, the distance an enemy will spawn from the major side it spawns from (this will be a larger value),
        // the distance an enemy will spawn from on the other axis (this will be a small value), the move speed of the enemy, the health of the enemy
        // the damage the enemy deals to the player, the index in the List of enemies (in the Game1 class)
        protected int spawnSide, mainSpawnDistance, offsetSpawnDistance, moveSpeed, health, damage, index;

        protected string type;                              // The enemy's type (O: Octopus, S: Slug, T: Tentacle

        // The x value of the location vector, the y value of the location vector, x value for the distance from the player, y value for the distance from the player, the angle to skew the enemy's movement
        protected float xLoc, yLoc, xDis, yDis, rotationAngle;

        protected Random rnd = new Random();                // A Random object
        protected const int HEIGHT = 40;                    // The height of the enemy is 40
        protected const int WIDTH = 40;                     // The width of the enemy is 40               
        protected Rectangle enemyBoundBox;                  // The bounding rectangle for an enemy
        protected int attackTimer;                          // The counter to delay the an enemy dealing damage
        protected int waveCounter;                          // Keeping track of the current wave number

        #endregion

        #region mutators/accessors

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int Index
        {
            get { return index; }
            set { index = value; }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public int Damage
        {
            get { return damage; }
        }

        public Rectangle EnemyBoundBox
        {
            get { return enemyBoundBox; }
        }

        public int height
        {
            get { return HEIGHT; }
        }

        public int width
        {
            get { return WIDTH; }
        }

        public Vector2 Loc
        {
            get { return loc; }
            set { loc = value; }
        }

        public float XLoc
        {
            get { return loc.X; }
            set { loc.X = value; }
        }

        public float YLoc
        {
            get { return loc.Y; }
            set { loc.Y = value; }
        }

        #endregion

        /// <summary>
        /// The constructor for an enemy
        /// </summary>
        /// <param name="waveNumber">The current wave number</param>
        /// <param name="windowWidth"> The width of the window</param>
        /// <param name="windowHeight"> The heigh of the window</param>
        /// <param name="theIndex">The index that the enemy has in the List of enemies (in the Game1 class)</param>
        public Enemy(int waveNumber, int windowWidth, int windowHeight, int theIndex)
        {
            EnemySpawnLocation(windowWidth, windowHeight);
            
            health = 20;
            moveSpeed = 1;
            attackTimer = 0;

            enemyBoundBox = new Rectangle((int) XLoc, (int) YLoc, WIDTH, HEIGHT);

            waveCounter = waveNumber;
        }

        /// <summary>
        /// Deals with enemy movement
        /// Each enemy will move differently, but all will go towards the player
        /// </summary>
        /// <param name="PlayerX">The player's x-value</param>
        /// <param name="PlayerY">The player's y-value</param>
        public abstract void Move(float PlayerX, float PlayerY);

        /// <summary>
        /// Spawning the enemy
        /// </summary>
        /// <param name="screenWidth">The width of the screen</param>
        /// <param name="screenHeight">The height of the screen</param>
        public void EnemySpawnLocation(int screenWidth, int screenHeight)
        {
            spawnSide = rnd.Next(0, 3);                 // Determine what side to spawn the enemy on
            mainSpawnDistance = rnd.Next(100, 200);     // Randomly determine how far the enemy will start on the main spawn side

            // On the other axis (not the axis of the main spawn side), the enemy will spawn between 0 and the length of that side of the screen
            if (spawnSide == 0) // left
            {
                offsetSpawnDistance = rnd.Next(0, screenHeight);
                loc = new Vector2(-mainSpawnDistance, offsetSpawnDistance);
                xLoc = -mainSpawnDistance;
                yLoc = offsetSpawnDistance;
            }
            else if (spawnSide == 1) // bottom
            {
                offsetSpawnDistance = rnd.Next(0, screenWidth);
                loc = new Vector2(offsetSpawnDistance, screenHeight + mainSpawnDistance);
                xLoc = offsetSpawnDistance;
                yLoc = screenHeight + mainSpawnDistance;
            }
            else if (spawnSide == 2) // right
            {
                offsetSpawnDistance = rnd.Next(0, screenHeight);
                loc = new Vector2(screenWidth + mainSpawnDistance, offsetSpawnDistance);
                xLoc = screenWidth + mainSpawnDistance;
                yLoc = offsetSpawnDistance;
            }
            else if (spawnSide == 3) // top
            {
                offsetSpawnDistance = rnd.Next(0, screenWidth);
                loc = new Vector2(offsetSpawnDistance, -mainSpawnDistance);
                xLoc = offsetSpawnDistance;
                yLoc = -mainSpawnDistance;
            }
        }

        /// <summary>
        /// Decrement the attack timer
        /// </summary>
        public void TimerCounter()
        {
            attackTimer--;
        }

        /// <summary>
        /// Attack only if the attack time is less than 0
        /// </summary>
        /// <returns>Whether to attack or not</returns>
        public bool Attack()
        {
            if (attackTimer <= 0)
            {
                attackTimer = 20;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Taking damage from bullets
        /// </summary>
        /// <param name="dam">The amount of damage</param>
        /// <returns>If the enemy has died</returns>
        public bool TakeDamage(int dam)
        {
            health -= dam;

            // If the enemy dies, drop ink
            if (health <= 0)
            {
                Drop();
                return true;
            }

            return false;
        }

        /// <summary>
        /// Drops ink
        /// </summary>
        /// <returns>The amount of ink dropped</returns>
        public abstract int Drop();
    }
}
