﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace InkInvasion
{
    class Bullet
    {
        #region variables

        private int damage;
        private const int WIDTH = 10;
        private const int HEIGHT = 10;
        private Vector2 vect;
        private float _x, _y;
        private const string imageLocation = "BulletSkinPNG";
        private int direction;
        private int index;
        private int sHeight, sWidth;
        private int speed;
        private Rectangle bulletBoundBox;

        #endregion

        #region accessors/mutators

        public Rectangle BulletBoundBox
        {
            get { return bulletBoundBox; }
        }

        public int Index
        {
            get { return index; }
            set { index = value; }
        }

        public int Direction
        {
            get { return direction; }
            set { direction = value; }
        }

        public int Damage
        {
            get { return damage; }
            set { damage = value; }
        }

        public Texture2D BulletSkin
        {
            get { return BulletSkin; }
            set { BulletSkin = value; }
        }

        public Vector2 Vect
        {
            get { return vect; }
            set { vect = value; }
        }

        public float Vect_X
        {
            get { return Vect.X; }
            set { vect.X = value; }
        }

        public float Vect_Y
        {
            get { return Vect.Y; }
            set { vect.Y = value; }
        }

        public string ImageLocation
        {
            get { return imageLocation; }
        }

        public float _X
        {
            get { return _x; }
            set { _x = value; }
        }

        public float _Y
        {
            get { return _y; }
            set { _y = value; }
        }

        #endregion

        #region functions

        public Bullet(int i, int dam, float x, float y, int dir, int w, int h)
        {
            speed = 8;
            sHeight = h;
            sWidth = w;
            Index = i;
            Damage = dam;
            Direction = dir;
            _X = x;
            _Y = y;
            Vect = new Vector2(_X, _Y);
            bulletBoundBox = new Rectangle((int) Vect_X, (int) Vect_Y, WIDTH, HEIGHT);
        }

        /// <summary>
        /// Updates the bullets X and Y according to the direction it
        /// had been fired
        /// </summary>
        public void Move()
        {
            switch (Direction)
            {
                case 3: _X -= speed; Vect_X -= speed; bulletBoundBox.X = (int)Vect_X; break;
                case 4: _X += speed; Vect_X += speed; bulletBoundBox.X = (int)Vect_X; break;
                case 1: _Y -= speed; Vect_Y -= speed; bulletBoundBox.Y = (int)Vect_Y; break;
                case 2: _Y += speed; Vect_Y += speed; bulletBoundBox.Y = (int)Vect_Y; break;
                default: break;
            }
        }

        /// <summary>
        /// Damages the enemy
        /// </summary>
        /// <param name="dam">Tells how much damage the bullet will do</param>
        /// <param name="ene">The enemy that is getting hit</param>
        public void DoDamage(Enemy ene)
        {
            //ene.health -= damage
            //if(ene.health <= 0)
            //  ene.die
            //bullet.(remove from screen)
        }

        public bool CheckBullet()
        {
            if (Vect_X <= 0) { return true; }
            if (Vect_Y <= 0) { return true; }
            if (Vect_X >= (sWidth - WIDTH)) { return true; }
            if (Vect_Y >= (sHeight - HEIGHT)) { return true; }
            return false;
        }

        #endregion
    }
}
