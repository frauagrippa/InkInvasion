﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InkInvasion
{
    class EnemyOctopus : Enemy
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="waveNumber">The current wave number</param>
        /// <param name="windowWidth">The width of the window</param>
        /// <param name="windowHeight">The height of the window</param>
        /// <param name="theIndex">The index of the enemy in the List of enemies (in the Game1 class)</param>
        public EnemyOctopus(int waveNumber, int windowWidth, int windowHeight, int theIndex)
            : base(waveNumber, windowWidth, windowHeight, theIndex)
        {
            index = theIndex;
            type = "O";                                     // This enemy is an octopus
            waveCounter = waveNumber;
            
            EnemySpawnLocation(windowWidth, windowHeight);  // Spawn the enemy

            health = 40 + (10 * (waveNumber / 2));          // Increases the octopus's health by 10 every other wave

            // Start changing the Octopus speed 5 waves after they first appear
            if (waveNumber > 10)
                moveSpeed = rnd.Next(2, 4);                 // Speed between 2 and 3
            else
                moveSpeed = 2;                              // Default speed of 2

            damage = 5;                                     // Octopus deals 5 damage

            enemyBoundBox = new Rectangle((int)XLoc, (int)YLoc, WIDTH, HEIGHT);

            attackTimer = 0;                                // They start with not delay on attack
        }

        /// <summary>
        /// Override the abstract Move from enemy
        /// </summary>
        /// <param name="PlayerX">The player's x-value</param>
        /// <param name="PlayerY">The player's y-value</param>
        public override void Move(float PlayerX, float PlayerY)
        {
            // The distances from the player
            xDis = XLoc - PlayerX;
            yDis = YLoc - PlayerY;

            rotationAngle = (float)Math.Atan2(yDis, xDis);                                      // Find the angle to fluctuate on

            XLoc -= (float)((moveSpeed + rnd.Next(-2, 2) / 1.4) * Math.Cos(rotationAngle));     // Fluctuate the x value of the enemy based off of a random number * the cos of the rotationAngle
            YLoc -= (float)((moveSpeed + rnd.Next(-2, 2) / 1.4) * Math.Sin(rotationAngle));     // Fluctuate the y value of the enemy based off of a random number * the sin of the rotationAngle

            // Modify where the bounding box is
            enemyBoundBox.X = (int)XLoc;
            enemyBoundBox.Y = (int)YLoc;

        }

        /// <summary>
        /// Deteremins how much ink an octopus drops
        /// </summary>
        /// <returns>The amount the octopus drops</returns>
        public override int Drop()
        {
            return 3 + (waveCounter / 3);       // Base drop of 3, Drop 1 more ink every 3 waves
        }
    }
}
